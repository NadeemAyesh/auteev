/*global $, jQuery, console, alert, prompt */
$(document).ready(function () {
    "use strict";
    $('.aside-dropdown > a.aside-nav-link').on('click', function (e) {
        e.preventDefault();
        if ($(this).hasClass('showen')) {
            $(this).removeClass('showen');
            $(this).parent().find('.drop-menu').slideUp('slow');
        } else {
            $(this).parent().find('.drop-menu').slideDown('slow');
            $(this).addClass('showen');
        }
        
    });

    $('body, html').on('click', function (e) {
        $('.drop-menu').slideUp('fast');
        $('.aside-dropdown > a.aside-nav-link').removeClass('showen');
    });

    $('.drop-menu, .aside-dropdown > a.aside-nav-link').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
    });

    const ps = new PerfectScrollbar('#main-menu', {
        wheelSpeed: 2,
        wheelPropagation: true,
        minScrollbarLength: 20
    });

    const pss = new PerfectScrollbar('#aside-content', {
        wheelSpeed: 2,
        wheelPropagation: true,
        minScrollbarLength: 20
    });

    if ($('select')) {
        $('select').niceSelect();
    }

    if ($('.datepicker')) {
        $('.datepicker').datepicker({
            orientation: 'bottom',
        });
    }

    if ($('#circleProgress')) {
        $('#circleProgress').circleProgress({
            value: 0.23,
            size: 150,
            fill: "#FFCA00"
        });
    }

    $('.back-btn button').on('click', function () {
        if($('.aside-right').hasClass('close')) {
            $('.aside-right').removeClass('close');
            $('.content-page').removeClass('no-right-side');
        } else {
            $('.aside-right').addClass('close');
            $('.content-page').addClass('no-right-side');
        }

    });

    $('.open-left-menu').on('click', function () {
        $('.aside-left').removeClass('close');
        $('.left-overlay').fadeIn('fast');
        $('.left-overlay').on('click', function () { 
            $('.left-overlay').fadeOut('fast');
            $('.aside-left').addClass('close');
        });
    });

    $(window).resize(function () {
        menus();
    });
    menus();
});

function menus() {
    if($(window).width() <= 991) {
        $('.aside-left').addClass('close');
        $('.content-page').removeClass('no-right-side');
    } else {
        $('.aside-left').removeClass('close');
        $('.left-overlay').fadeOut('fast');
        $('.content-page').addClass('no-right-side');
    }

    if($(window).width() <= 1024) {
        $('.aside-right').addClass('close');
        $('.content-page').removeClass('no-right-side');
    } else {
        $('.aside-right').removeClass('close');
        $('.left-overlay').fadeOut('fast');
        $('.content-page').addClass('no-right-side');
    }
}

// upload file

function readURL(input) {
    if (input.files && input.files[0]) {

        var reader = new FileReader();

        reader.onload = function (e) {
            $('.image-upload-wrap').hide();

            $('.file-upload-image').attr('src', e.target.result);
            $('.file-upload-content').show();

            $('.image-title').html(input.files[0].name);
        };

        reader.readAsDataURL(input.files[0]);

    } else {
        removeUpload();
    }
}

function removeUpload() {
    $('.file-upload-input').replaceWith($('.file-upload-input').clone());
    $('.file-upload-content').hide();
    $('.image-upload-wrap').show();
}
$('.image-upload-wrap').bind('dragover', function () {
    $('.image-upload-wrap').addClass('image-dropping');
});
$('.image-upload-wrap').bind('dragleave', function () {
    $('.image-upload-wrap').removeClass('image-dropping');
});